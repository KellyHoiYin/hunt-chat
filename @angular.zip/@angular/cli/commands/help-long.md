 For help with individual commands, use the `--help` or `-h` option with the command.

 For example,

 ```sh
 ng help serve
 ```
